package com.example.skincare_trackerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
